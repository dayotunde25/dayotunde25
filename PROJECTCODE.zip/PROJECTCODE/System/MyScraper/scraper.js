const puppeteer = require('puppeteer'); 

async function scrapeProduct(url) { 
    const browser = await puppeteer.launch(); 
    const page = await browser.newPage(); 
    await page.goto(url);
    const [el] = await page.$x('/html/body/main/section/div[2]/div[2]/div[1]/div[3]/div[1]/div[2]/div/div[1]/a/span');
    const src = await el.getProperty('src');
    const srcText = await src.jsonValue();
    console.log({srcText});
    browser.close();

}

scrapeProduct('https://www.jobberman.com/jobs');