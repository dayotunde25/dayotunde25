<?php

$con = mysqli_connect("localhost", "root", "", "job_portal");
$st = mysqli_prepare($con, 'INSERT INTO scraped_jobs(job_url, company_name, job_title, job_location, description) VALUES (?, ?, ?, ?, ?)');
mysqli_stmt_bind_param($st,'sssss',  $job_url, $company_name, $job_title, $location, $description);

$data = file_get_contents('newjSearch.json',true);
$joba = json_decode($data, true); 

foreach($joba['data'] as $key=>$value){ 
   $job_url = $value["job_apply_link"];  
   $company_name = $value["employer_name"];
   $job_title = $value["job_title"];
   $location = $value['job_country'].' '.$value['job_city'];
   $description = $value['job_description'];
	mysqli_stmt_execute($st);
}
if($con && $st){ 
	echo "Connected Successfully"; 
} else{
    die("connection failed".mysqli_connect_error());
}


?>