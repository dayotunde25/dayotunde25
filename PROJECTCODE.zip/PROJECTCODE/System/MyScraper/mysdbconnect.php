<?php
 $con = mysqli_connect("localhost", "root", "", "demo");
 $st = mysqli_prepare($con, 'INSERT INTO user(full_name,address_main,dateofreg,username,psword,country) VALUES (?, ?, ?, ?, ?, ?)');
 mysqli_stmt_bind_param($st,'ssssss',  $full_name, $address, $dateofreg, $username, $psword, $country);
 
 $data = file_get_contents('testtest.json');
 $array = json_decode($data, true); 
 foreach($array['jobs'] as $key=>$value){ 
    $full_name = $value['title']; 
    $address =  $value['location']; 
    $dateofreg =  $value["updated"];
    $username =  $value["link"];
    $psword =  $value["company"];
    $country =  $value["source"];
     mysqli_stmt_execute($st);
 }
 
 if($con && $st){ 
    echo "Connected Successfully";
 }else{
    die("connection failed".mysqli_connect_error());
 }
?>