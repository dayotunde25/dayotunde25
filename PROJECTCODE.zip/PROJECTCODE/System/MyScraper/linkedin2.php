<?php
$con = mysqli_connect("localhost", "root", "", "job_portal");

$st = mysqli_prepare($con, 'INSERT INTO scraped_jobs(job_url, linkedin_job_url_cleaned, company_name, company_url, job_title, job_location, posted_date, description) VALUES (?, ?, ?, ?, ?, ?, ?)');
mysqli_stmt_bind_param($st,'sssssss',  $job_url, $linkedin_job_url_cleaned, $company_name, $job_title, $job_location, $posted_date, $normalized_company_name);

$curl = curl_init();

curl_setopt_array($curl, [
	CURLOPT_URL => "https://linkedin-jobs-search.p.rapidapi.com/",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_FOLLOWLOCATION => true,
	CURLOPT_ENCODING => "",
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "POST",
	CURLOPT_POSTFIELDS => "{\r\n    \"search_terms\": \"\",\r\n    \"location\":\"us\",\r\n    \"page\": \"10\"\r\n}",
	CURLOPT_HTTPHEADER => [
		"X-RapidAPI-Host: linkedin-jobs-search.p.rapidapi.com",
		"X-RapidAPI-Key: b85e43b376msh24baf6ffbcfeeb3p14438ajsn3a55fc11c03d",
		"content-type: application/json"
	],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl); 
//$data = file_get_contents($response); 
$joba = json_decode($response, true); 

foreach($joba as $key=>$value){ 
   $job_url = $value["job_url"]; 
   $linkedin_job_url_cleaned = $value["linkedin_job_url_cleaned"]; 
   $company_name = $value["company_name"];
   $job_title = $value["job_title"];
   $job_location = $value["job_location"];
   $posted_date = $value["posted_date"];
   $normalized_company_name = $value["normalized_company_name"];
	mysqli_stmt_execute($st);
}

?>