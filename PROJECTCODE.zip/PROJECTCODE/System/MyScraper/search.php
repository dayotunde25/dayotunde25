<! DOCTYPE html> 
<html> 
    <head> <title>Results</title> </head> 
    <body>
        <form action="sfunc.php" method="GET">
            <input type="text" name="query"> 
            <input type="submit" value="Search Jobs">
        </form>
</body> 
</html>