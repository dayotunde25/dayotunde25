const linkedIn = require("./index");

const queryOptions = {
  keyword: "",
  location: "US",
  dateSincePosted: "past Week",
  jobType: "full time",
  remoteFilter: "",
  salary: "",
  experienceLevel: "",
  limit: "100",
  sortBy: "recent",
};

linkedIn.query(queryOptions).then((response) => {
  console.log(response); // An array of Job objects
});
